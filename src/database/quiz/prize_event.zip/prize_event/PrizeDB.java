package database.quiz.prize_event;

public class PrizeDB {

}
